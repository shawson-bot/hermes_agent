"""Schemas exposed by the competition proposal workflow plugin."""

START_COMPETITION_PROPOSAL_WORKFLOW = {
    "name": "start_competition_proposal_workflow",
    "description": (
        "Stage uploaded or prepared competition-proposal inputs into a unique "
        "per-run workspace, perform host-side validation, and create the "
        "competition proposal Kanban board with a manual outline approval gate. This is the only valid "
        "preflight because sandboxed file tools cannot see host paths. Use this "
        "instead of inspecting host paths or manually creating or linking "
        "competition-proposal workflow tasks."
    ),
    "parameters": {
        "type": "object",
        "properties": {
            "run_name": {
                "type": "string",
                "description": (
                    "Optional unique run name used for the board and "
                    "idempotency keys. Omit it to generate a non-repeating "
                    "timestamped name after checking the existing Kanban "
                    "board directory."
                ),
            },
            "competition_type": {
                "type": "string",
                "enum": [
                    "",
                    "national-innovation-award",
                    "ai-health-innovation",
                ],
                "default": "",
                "description": (
                    "Optional explicit competition type. If omitted, the "
                    "writer infers it from the staged guideline source and defaults to "
                    "national-innovation-award when still unclear."
                ),
            },
            "max_retries": {
                "type": "integer",
                "minimum": 1,
                "maximum": 5,
                "default": 2,
                "description": "Maximum worker retries per task.",
            },
            "uploaded_files": {
                "type": "array",
                "items": {"type": "string"},
                "default": [],
                "description": (
                    "Local backend cache paths for files uploaded in the current "
                    "Studio/chat message. Pass the paths from attachment notes "
                    "such as \"saved at: /path/to/file\". The launcher will infer "
                    "roles from filenames and copy them into the per-run "
                    "input_docs folder. Supported inputs are Markdown/text, PDF, DOCX, and common image files."
                ),
            },
            "input_files": {
                "type": "object",
                "additionalProperties": False,
                "properties": {
                    "guideline": {
                        "type": "string",
                        "description": "Explicit backend path for the guideline source file.",
                    },
                    "company_data": {
                        "type": "string",
                        "description": "Explicit backend path for the company/team source file.",
                    },
                    "product_data": {
                        "type": "string",
                        "description": "Explicit backend path for the product/service source file.",
                    },
                },
                "description": (
                    "Explicit role-to-path mapping for uploaded or prepared files. "
                    "Use this when filenames are ambiguous; these values override "
                    "role inference from uploaded_files."
                ),
            },
            "reuse_project_inputs": {
                "type": "boolean",
                "default": True,
                "description": (
                    "When true, any missing role falls back to the legacy shared "
                    "$HERMES_COMPETITION_PROPOSAL_ROOT/input_docs folder. Keep true "
                    "for local CLI testing; uploaded files still stage into a "
                    "unique per-run workspace."
                ),
            },
            "reuse_run_inputs_from": {
                "type": "string",
                "description": (
                    "Optional previous run name to seed a new outline iteration. "
                    "The launcher copies that run's available source roles and "
                    "supporting files, then adds any newly uploaded files or "
                    "additional_requirements."
                ),
            },
            "additional_requirements": {
                "type": "string",
                "description": (
                    "Optional user-supplied requirements, corrections, or missing "
                    "information after rejecting a prior outline. The launcher "
                    "writes this into input_docs/user-additional-requirements-supporting.md "
                    "for the new iteration."
                ),
            },
            "dispatch": {
                "type": "boolean",
                "default": True,
                "description": "Run one dispatcher pass after creating the board.",
            },
            "subscribe_updates": {
                "type": "boolean",
                "default": True,
                "description": (
                    "Subscribe the current gateway/TUI chat session to each "
                    "workflow task so completion/block messages are emitted "
                    "after every step when the active surface supports async "
                    "Kanban notifications."
                ),
            },
            "dry_run": {
                "type": "boolean",
                "default": False,
                "description": (
                    "Validate Docker, host files, and workflow dependencies "
                    "without creating a board."
                ),
            },
            "wait_for_intake": {
                "type": "boolean",
                "default": True,
                "description": (
                    "Wait for the Intake task to finish or block so its result "
                    "can be relayed by the Competition Proposal Orchestrator."
                ),
            },
            "intake_wait_seconds": {
                "type": "integer",
                "minimum": 10,
                "maximum": 300,
                "default": 120,
                "description": "Maximum time to wait for the Intake task result.",
            },
        },
        "required": [],
    },
}


APPROVE_COMPETITION_PROPOSAL_OUTLINE = {
    "name": "approve_competition_proposal_outline",
    "description": (
        "Complete the manual outline approval gate for a competition proposal "
        "run and dispatch downstream drafting/review tasks. Use only after the "
        "user has explicitly approved the presented outline."
    ),
    "parameters": {
        "type": "object",
        "properties": {
            "run_name": {
                "type": "string",
                "description": "Run name returned by start_competition_proposal_workflow.",
            },
            "board": {
                "type": "string",
                "description": "Optional Kanban board slug if run_name is unavailable.",
            },
            "project_root": {
                "type": "string",
                "description": "Optional per-run project root.",
            },
            "task_id": {
                "type": "string",
                "description": (
                    "Optional outline approval task id. Omit when the run manifest "
                    "or tasks map is available."
                ),
            },
            "tasks": {
                "type": "object",
                "additionalProperties": {"type": "string"},
                "description": "Optional task-id map returned by the workflow starter.",
            },
            "approval_note": {
                "type": "string",
                "description": "Optional short note describing what the user approved.",
            },
            "dispatch": {
                "type": "boolean",
                "default": True,
                "description": "Run one dispatcher pass after approving the gate.",
            },
            "include_artifacts": {
                "type": "boolean",
                "default": True,
                "description": "Include artifact previews in the returned status digest.",
            },
        },
        "required": [],
    },
}


GET_COMPETITION_PROPOSAL_WORKFLOW_STATUS = {
    "name": "get_competition_proposal_workflow_status",
    "description": (
        "Return an orchestrator-facing progress digest for a competition "
        "proposal run. Use this after starting the workflow, after Kanban task "
        "notifications, or when the user asks for status. It reads Kanban state "
        "plus known worker artifacts and produces one user-facing message so "
        "the Competition Proposal Orchestrator can remain the only communicator."
    ),
    "parameters": {
        "type": "object",
        "properties": {
            "run_name": {
                "type": "string",
                "description": (
                    "Run name returned by start_competition_proposal_workflow. "
                    "Used to derive the board and per-run project folder when "
                    "board or project_root is omitted."
                ),
            },
            "board": {
                "type": "string",
                "description": (
                    "Optional Kanban board slug, such as "
                    "competition-proposal-national-award-test."
                ),
            },
            "project_root": {
                "type": "string",
                "description": (
                    "Optional per-run project root. Omit when run_name was used "
                    "with the canonical launcher."
                ),
            },
            "tasks": {
                "type": "object",
                "additionalProperties": {"type": "string"},
                "description": (
                    "Optional task-id map returned by "
                    "start_competition_proposal_workflow."
                ),
            },
            "include_artifacts": {
                "type": "boolean",
                "default": True,
                "description": (
                    "Include short previews and existence checks for known "
                    "worker artifacts such as intake_manifest.md, source_summary.md, "
                    "mapping.md, outline.md, draft.md, checklist.md, and final outputs."
                ),
            },
            "artifact_max_chars": {
                "type": "integer",
                "minimum": 400,
                "maximum": 12000,
                "default": 3000,
                "description": "Maximum characters to include from each artifact preview.",
            },
        },
        "required": [],
    },
}
