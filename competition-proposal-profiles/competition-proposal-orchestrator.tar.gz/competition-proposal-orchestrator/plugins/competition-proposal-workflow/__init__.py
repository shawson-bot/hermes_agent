"""Register the competition proposal workflow tools."""

from __future__ import annotations

from .schemas import (
    APPROVE_COMPETITION_PROPOSAL_OUTLINE,
    GET_COMPETITION_PROPOSAL_WORKFLOW_STATUS,
    START_COMPETITION_PROPOSAL_WORKFLOW,
)
from .tools import (
    approve_competition_proposal_outline,
    get_competition_proposal_workflow_status,
    start_competition_proposal_workflow,
)


def register(ctx) -> None:
    ctx.register_tool(
        name="start_competition_proposal_workflow",
        toolset="competition_proposal_workflow",
        schema=START_COMPETITION_PROPOSAL_WORKFLOW,
        handler=start_competition_proposal_workflow,
    )
    ctx.register_tool(
        name="get_competition_proposal_workflow_status",
        toolset="competition_proposal_workflow",
        schema=GET_COMPETITION_PROPOSAL_WORKFLOW_STATUS,
        handler=get_competition_proposal_workflow_status,
    )
    ctx.register_tool(
        name="approve_competition_proposal_outline",
        toolset="competition_proposal_workflow",
        schema=APPROVE_COMPETITION_PROPOSAL_OUTLINE,
        handler=approve_competition_proposal_outline,
    )
