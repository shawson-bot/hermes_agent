#!/usr/bin/env sh
set -eu

IMAGE="${HERMES_COMPETITION_PROPOSAL_DOCKER_IMAGE:-hermes-report-sandbox:rtk-0.43.0}"
INSTALL_MARKER="${HERMES_COMPETITION_PROPOSAL_INSTALL_MARKER:-0}"
DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"

docker build \
  --build-arg INSTALL_MARKER="$INSTALL_MARKER" \
  -t "$IMAGE" \
  -f "$DIR/Dockerfile" \
  "$DIR"
docker run --rm "$IMAGE" sh -lc 'rtk --version && python --version && node --version && python - <<PY
import fitz
import docx
from PIL import Image
print("pymupdf/python-docx/pillow ok")
PY'
