# Competition Proposal Backend Runtime Cookbook

This profile bundle intentionally does not include machine-local runtime state:

- Docker images
- auth files, provider keys, logs, sessions, memories, or caches
- old workflow run folders

After importing the profiles into Hermes Studio, run these commands on the
backend device that hosts Hermes Studio.

## 1. Enter the orchestrator profile

```sh
cd ~/.hermes/profiles/competition-proposal-orchestrator
```

## 2. Build the RTK + document extraction Docker sandbox image

The competition-proposal worker agents expect this image by default:

```text
hermes-report-sandbox:rtk-0.43.0
```

Build it once. The default build includes RTK plus lightweight document
extraction dependencies: `pymupdf`, `pymupdf4llm`, `python-docx`, and `pillow`.
This supports text-based PDFs, DOCX files, and image metadata/loading checks.

```sh
scripts/docker/rtk-report/build.sh
```

Verify it:

```sh
docker image ls | grep hermes-report-sandbox
docker run --rm hermes-report-sandbox:rtk-0.43.0 sh -lc 'rtk --version && python - <<PY
import fitz
import docx
from PIL import Image
print("document extraction deps ok")
PY'
```

For scanned PDFs or image OCR, install the heavier `marker-pdf` stack into the
image. This can add several GB and may download models on first use:

```sh
HERMES_COMPETITION_PROPOSAL_INSTALL_MARKER=1 scripts/docker/rtk-report/build.sh
```

Without marker OCR, Source Reader will still handle Markdown/text, DOCX, and
text-based PDFs. It will block with a clear action item for scanned PDFs/images
that need OCR.

To use another image name, set this on the backend before running the workflow:

```sh
export HERMES_COMPETITION_PROPOSAL_DOCKER_IMAGE=your-image-name:tag
```

## 3. Project folder behavior

Each workflow run creates an isolated run folder:

```text
~/hermes-projects/competition_proposal/runs/<run_id>/
  input_docs/
  jobs/
  outputs/
  scratch/
```

Uploaded Studio/chat attachments are staged into the run-specific
`input_docs/` folder. Worker agents receive Docker mounts for only the current
run folder, translated inside Docker as `/workspace/...`.

The export does not include old `runs/` folders. That is expected; run folders
are generated at runtime.

## 4. Provider credentials

Provider credentials must be configured on the backend. They are not exported.

Check Hermes Studio provider/env settings after import, then test the workflow
from the orchestrator profile.
