---
name: competition-proposal
description: >
  整理與檢核競賽／計畫書。當使用者提供競賽簡章與公司/產品資料（Markdown），
  並要求產出計畫書初稿、檢核報告、缺漏與行政待辦清單或 QA 題庫時觸發。
  檢核報告含結論狀態（可投稿／需補件／高風險不建議投稿）、內容品質檢核
  （空泛／過度承諾／缺來源）、缺漏清單（含負責角色）、行政待辦與回問問題。
  適用於各類競賽計畫書，不限特定競賽或產業。
---

# 競賽計畫書 Skill

## Hermes Kanban Workflow Override

若本 skill 是由 `competition-proposal-writer` 在 Hermes Kanban 工作流中載入，請以 Kanban 任務 body 與 Writer `SOUL.md` 指定的階段性產物為最高優先序：

- Outline 任務產出 `/workspace/jobs/mapping.md` 與 `/workspace/jobs/outline.md`。
- Draft 任務只產出 `/workspace/jobs/draft.md`，且必須等 Outline Approval gate 完成後才執行。
- Revision 任務讀取 Reviewer 產出的 `/workspace/jobs/checklist.md`，再產出 `/workspace/outputs/draft.md`、`/workspace/outputs/qa-bank.md` 與可行時的 DOCX。
- 不要在 Writer 的 Outline 或 Draft 任務自行產出 `checklist.md`；此檔由 Reviewer 負責。
- 可沿用本 skill 的競賽類型判斷、章節範本、寫作規則、缺漏標記與 QA-bank 規則，但不要覆蓋工作流指定的檔名與階段邊界。

以下是一鍵獨立執行模式的原始說明；只有在沒有 Kanban 階段任務約束時才完整套用。

照 `prompts/writer.md` 執行，一鍵產出兩類輸出：

- **A. 計畫書初稿**：`draft.md`（依競賽類型範本）
- **B. 計畫書檢核報告**：`checklist.md`（結論狀態、內容品質檢核、缺漏清單含負責角色、行政待辦、回問問題、成效紀錄）

另含 `mapping.md`（要求-內容對應表）與 `qa-bank.md`（模擬評審問答，10–25 題）。

預設：完成後將 `draft.md` 匯出為可編輯 `.docx` 作為最終交付成果檔（見 `references/docx-export.md`；markdown 仍保留為工作檔，僅在使用者明確表示「只要 markdown」時略過）。
