# 要求-內容對應表

- **競賽類型**：國家新創獎
- **簡章來源**：/home/node/.openclaw/workspace/skills/competition-proposal/runs/test-national/guideline.md
- **公司資料**：/home/node/.openclaw/workspace/skills/competition-proposal/runs/test-national/company-data.md
- **產品資料**：/home/node/.openclaw/workspace/skills/competition-proposal/runs/test-national/product-data.md
- **產出時間**：2026-06-18

## 狀態圖例

| 符號 | 意義 |
|------|------|
| `✅` | 資料完整，可直接寫入 draft |
| `⚠️` | 部分資料存在，需確認或補述 |
| `[待補充]` | 輸入資料無對應欄位，禁止捏造 |

## 對應表主體

| # | section-id | 簡章要求 | 對應內容 | 資料來源 | 狀態 |
|---|------------|---------|---------|---------|------|
| 1 | NI-01 | 摘要：問題定義 | 長照人力缺口，照服員重複提醒工時過高 | product-data | `✅` |
| 2 | NI-01 | 摘要：解決方案 | CareNova 生成式 AI 照護機器人 | product-data | `✅` |
| 3 | NI-01 | 摘要：目標客群 | 長照機構、醫院復健單位 | product-data | `✅` |
| 4 | NI-01 | 摘要：競爭優勢 | 繁中/台語在地化 RAG、三合一架構、邊緣優先 | product-data | `✅` |
| 5 | NI-01 | 摘要：商業模式 | 硬體銷售 + SaaS 訂閱 + 建置服務 + 加值模組 | product-data | `✅` |
| 6 | NI-01 | 摘要：現況里程碑 | 2025 Q3 日照中心 3 個月 PoC、Pre-A 募資 1,200 萬 | company-data | `✅` |
| 7 | NI-02-A | 公司名稱 | 長聯科技股份有限公司 | company-data | `✅` |
| 8 | NI-02-B | 負責人 | 陳志遠 | company-data | `✅` |
| 9 | NI-02-C | 成立時間 | 2021 年 3 月 15 日 | company-data | `✅` |
| 10 | NI-02-D | 資本額 | 新台幣 2,000 萬元 | company-data | `✅` |
| 11 | NI-02-E | 最近年度營業額 | 1,850 萬元（2025 年度，未經查核） | company-data | `⚠️` |
| 12 | NI-02-F | 近三年營業額逐年度 | 資料缺漏，待補充 | company-data | `[待補充]` |
| 13 | NI-02-G | 研發經費 | 約 620 萬元/年（占營收 33%） | company-data | `✅` |
| 14 | NI-02-H | 員工總數 | 18 人（正職 15、約聘 3） | company-data | `✅` |
| 15 | NI-02-I | 經營團隊（≥2 人） | 陳志遠（執行長）、林雅婷（營運長） | company-data | `✅` |
| 16 | NI-02-J | 研發團隊（≥2 人） | 王承翰（技術長）、張語晴（AI 研究主管） | company-data | `✅` |
| 17 | NI-02-K | 專利/智財清單 | 2 件（1 發明審查中、1 新型已核准） | company-data | `✅` |
| 18 | NI-03 | 核心團隊互補性 | 技術（王、張）+ 商業/營運（陳、林） | company-data | `✅` |
| 19 | NI-03 | 相關年資與落地經驗 | 10 年以上醫療/長照產業經驗、PoC 完成 | company-data | `✅` |
| 20 | NI-03 | 顧問/投資人/策略夥伴 | Pre-A 天使 + 策略投資人（未列名） | company-data | `⚠️` |
| 21 | NI-03 | 組織治理與分工 | 有明確 C-level 分工 | company-data | `✅` |
| 22 | NI-04-A | 技術原理與架構 | Jetson AGX + ROS2 + 五模組架構 | product-data | `✅` |
| 23 | NI-04-B | 創新點與可驗證指標 | 延遲 P95<2.5s、uptime 99.5%、PoC 減少 18% 工時 | product-data | `⚠️` |
| 24 | NI-04-C | 原型/試點階段 | 2025 Q3 日照中心 3 個月 PoC | product-data | `✅` |
| 25 | NI-04-D | 法規/資安/醫療標準 | 邊緣推論、去識別化、RBAC、安全護欄 | product-data | `⚠️` |
| 26 | NI-05-A | 目標市場規模 | TAM 120-180 億、SAM 15-20 億、SOM 1.2 億 | product-data | `⚠️` |
| 27 | NI-05-B | 客戶痛點與價值主張 | 人力缺口、重複提醒工時、照護紀錄輔助 | product-data | `✅` |
| 28 | NI-05-C | 定價與獲客方式 | 硬體 98 萬 + 訂閱 18 萬/年、機構直銷 | product-data | `✅` |
| 29 | NI-05-D | 競品分析與差異化 | 繁中/台語在地化、三合一、邊緣優先 | product-data | `✅` |
| 30 | NI-05-E | 營收模型與損益平衡 | 月銷 8 台 + 續約率 85%、2027 Q2 預估平衡 | product-data | `⚠️` |
| 31 | NI-06-A | 專利布局 | 2 件（發明審查中、新型已核准） | company-data | `✅` |
| 32 | NI-06-B | FTO 風險與迴避策略 | [待補充] | company-data | `[待補充]` |
| 33 | NI-06-C | 技術授權/共研/OEM 智財歸屬 | [待補充] | company-data | `[待補充]` |
| 34 | NI-06-D | 資料與模型使用合規 | 去識別化、RBAC、邊緣推論降低外傳 | product-data | `✅` |
| 35 | NI-07-1 | 公司登記證明 | [待補充] | company-data | `[待補充]` |
| 36 | NI-07-2 | 專利證書或申請案號清單 | 有編號但無 PDF 附件 | company-data | `⚠️` |
| 37 | NI-07-3 | 產品/技術簡報 | [待補充] | company-data | `[待補充]` |
| 38 | NI-07-4 | 財務或投資證明 | Pre-A 1,200 萬（無增資紀錄 PDF） | company-data | `⚠️` |
| 39 | NI-07-5 | 客戶/試點證明 | 有 PoC 描述但無合約/推薦函 | company-data | `⚠️` |
| 40 | NI-07-6 | 智財檢索或 FTO 摘要 | [待補充] | company-data | `[待補充]` |

## 待補充項目彙整

| section-id | 缺漏項目 | 建議補件方式 |
|------------|----------|--------------|
| NI-02-F | 近三年營業額（2023、2024、2025 分年度） | 向財會索取分年度報表 |
| NI-03 | 顧問/投資人/策略夥伴名單與角色 | 補充完整名單與合作內容 |
| NI-04-B | PoC 準確率/效率等可驗證指標詳細數據 | 提供試點完整報告 |
| NI-04-D | 法規/資安/醫療標準符合性證明 | 提供認證或合規文件 |
| NI-05-A | TAM/SAM/SOM 來源出處 | 附第三方報告或引用來源 |
| NI-05-E | 損益平衡假設之詳細成本結構 | 提供財務模型備查 |
| NI-06-B | FTO 風險分析 | 委託智財機構或自行檢索 |
| NI-06-C | 技術授權/共研/OEM 智財歸屬 | 補充合作合約摘要 |
| NI-07-1 | 公司登記證明 PDF | 上傳公司登記證明 |
| NI-07-2 | 專利證書 PDF | 上傳專利證書或申請案號清單 |
| NI-07-3 | 產品/技術簡報 PDF | 製作 15-20 頁簡報 |
| NI-07-4 | 財務或投資證明 PDF | 提供增資紀錄或 LOI |
| NI-07-5 | 客戶/試點證明 | 提供合約摘要、試用報告或推薦函 |
| NI-07-6 | 智財檢索或 FTO 摘要 | 提供智財檢索報告 |