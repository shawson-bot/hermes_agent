# 要求-內容對應表

> 產出檔名：`mapping.md`  
> 用途：將簡章每一項要求對應至 company-data / product-data 之具體欄位或段落，並標示完成狀態。

## 文件標頭（填寫執行時之中繼資料）

```markdown
# 要求-內容對應表

- **競賽類型**：{type}
- **簡章來源**：{guideline path}
- **公司資料**：{company-data path}
- **產品資料**：{product-data path}
- **產出時間**：{YYYY-MM-DD}
```

## 狀態圖例

| 符號 | 意義 |
|------|------|
| ✅ | 資料完整，可直接寫入 draft |
| ⚠️ | 部分資料存在，需確認或補述 |
| [待補充] | 輸入資料無對應欄位，禁止捏造 |

## 對應表主體

依競賽類型選用對應 section-id（見 `references/competition-types/`）。每一簡章要求至少一列。

### 國家新創獎範例表頭

| # | section-id | 簡章要求 | 對應內容 | 資料來源 | 狀態 |
|---|------------|---------|---------|---------|------|
| 1 | NI-01 | 摘要 500 字內：問題定義 | {從 product-data 問題／定位摘錄} | product-data | ✅ |
| 2 | NI-01 | 摘要：解決方案 | {產品一句話定位 + 核心模組} | product-data | ✅ |
| 3 | NI-02-F | 近三年營業額逐年度 | [待補充] | company-data | [待補充] |
| 4 | NI-03 | 核心團隊互補性 | {經營＋研發分工敘述} | company-data | ✅ |
| 5 | NI-04 | 技術架構與模組 | {product-data 技術架構章} | product-data | ✅ |
| 6 | NI-05 | TAM/SAM/SOM | {product-data 目標市場表} | product-data | ⚠️ |
| 7 | NI-06 | 專利清單 | {company-data 智財表} | company-data | ✅ |
| 8 | NI-07-1 | 公司登記證明 | [待補充] | company-data | [待補充] |

### AI 大健康大賽範例表頭

| # | section-id | 簡章要求 | 對應內容 | 資料來源 | 狀態 |
|---|------------|---------|---------|---------|------|
| 1 | AH-01 | 核心成員 ≥ 3 位 | {company-data 經營＋研發團隊} | company-data | ✅ |
| 2 | AH-01 | 跨領域能力矩陣 | {依成員專長整理} | company-data | ⚠️ |
| 3 | AH-02 | 五大功能模組 | {product-data 核心模組章} | product-data | ✅ |
| 4 | AH-02 | 開發進度 | {試點／PoC 描述} | company-data + product-data | ✅ |
| 5 | AH-03 | 可量化效能提升 | {PoC 18% 工時等} | company-data | ⚠️ |
| 6 | AH-04 | 競品比較表 | {product-data 競爭差異化} | product-data | ⚠️ |
| 7 | AH-05 | 法規路徑 | [待補充] | — | [待補充] |
| 8 | AH-06 | 3 年營收預估 | {product-data 損益平衡假設} | product-data | ⚠️ |

## 填寫規則

1. **涵蓋所有主要章節**：國家新創獎須含 NI-01～NI-07；AI 大健康須含 AH-01～AH-06 及附件合規項。
2. **一要求一列或多列**：複雜表格（如 NI-02 基本資料表）可拆成多列，# 連續編號。
3. **對應內容欄**：摘出實際摘錄、欄位名或 `[待補充]`，不得寫「見上文」。
4. **資料來源欄**：僅填 `company-data`、`product-data`、`guideline` 或其組合；附件缺件填 `—`。
5. **禁止捏造**：無輸入支撐之數字、日期、人名、案號一律 `[待補充]`。

## 章節覆蓋檢查（agent 自檢）

完成 mapping 後，確認下列 section-id 至少各出現一次：

**national-innovation-award**：NI-01, NI-02, NI-03, NI-04, NI-05, NI-06, NI-07  
**ai-health-innovation**：AH-01, AH-02, AH-03, AH-04, AH-05, AH-06

## 缺漏彙整區（建議附於表末）

```markdown
## 待補充項目彙整

| section-id | 缺漏項目 | 建議補件方式 |
|------------|----------|--------------|
| NI-02-F | 近三年營業額 | 向財會索取 2023–2025 分年度報表 |
| NI-07-1 | 公司登記證明 | 上傳 PDF 至附件資料夾 |
```
