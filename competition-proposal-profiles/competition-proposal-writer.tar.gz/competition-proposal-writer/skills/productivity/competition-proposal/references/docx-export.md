# 成果檔輸出：draft.md → .docx

> 將本 skill 產出的計畫書 Markdown 轉為可編輯的 Word（.docx）成果檔。
> 主要用途：`draft.md`（計畫書本體）常需以 .docx 繳交或給團隊在 Word 中續編。

## 何時執行

- **預設執行**：markdown 產出後,自動把 `draft.md` 轉成 `.docx` 作為最終交付成果檔。
- markdown 檔仍會保留（供檢核、續編、轉檔來源使用），但**交付重點為 .docx**。
- 例外：使用者明確表示「只要 markdown / 不用 docx」時才略過。

## 轉哪一份

| 檔案 | 是否預設轉 docx | 說明 |
|------|----------------|------|
| `draft.md` | ✅ 預設 | 計畫書本體,最常需要 Word 版繳交 |
| `checklist.md` | 使用者指定才轉 | 內部檢核報告,通常留 md 較好用 |
| `mapping.md` / `qa-bank.md` | 使用者指定才轉 | 工作用檔,一般不轉 |

使用者可覆寫,例如「draft 跟 checklist 都要 docx」。

## 轉檔指令（pandoc）

```bash
# 基本:draft.md → draft.docx（存到本次 runs/<id>/）
pandoc runs/<id>/draft.md -o runs/<id>/draft.docx

# 建議:加目錄、章節編號,提升計畫書可讀性
pandoc runs/<id>/draft.md -o runs/<id>/draft.docx --toc --number-sections

# 有公司 Word 範本（樣式/頁首頁尾）時,套用參考樣式
pandoc runs/<id>/draft.md -o runs/<id>/draft.docx --reference-doc=/path/to/company-template.docx
```

> `--reference-doc` 的範本檔即一般 .docx,其樣式(標題級距、字體、頁首頁尾)會套用到輸出。
> 需要更精緻的排版/圖表/追蹤修訂時,改用內嵌的官方 `docx` skill(見 `references/docx/`,
> 若本 skill 未內嵌,可沿用 `api-doc-review/references/docx/`)。

## 依賴

```bash
brew install pandoc          # 純文字轉換足夠
# 進階排版/樣式：官方 docx skill 需 `npm install -g docx` 與 LibreOffice(soffice)
```

## 輸出與回報

- `.docx` 存到該次 `runs/<id>/`(例如 `runs/<id>/draft.docx`)。
- 回報使用者:檔案路徑、由哪份 md 轉出、是否套用範本樣式。
- **不得於轉檔時竄改內容**:`[待補充]` 佔位一律原樣保留,不得捏造補齊。
- pandoc 未安裝時,明確告知需先 `brew install pandoc`,不要靜默略過。
