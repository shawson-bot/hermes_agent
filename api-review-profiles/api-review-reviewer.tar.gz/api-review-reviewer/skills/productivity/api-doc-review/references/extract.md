# 輸入擷取：PDF / Word / 其他格式 → 純文字

> 當使用者提供的 API 文件是**檔案**（而非直接貼上的文字）時，先用本指南把內容擷取成純文字，
> 再交由 `prompts/reviewer.md` 審查。
> PDF 封裝自 Anthropic 官方 `pdf` skill（內嵌於 `references/pdf/`）；
> DOCX 封裝自官方 `docx` skill（內嵌於 `references/docx/`）。
> 來源：https://github.com/anthropics/skills/tree/main/skills/pdf
> 　　　https://github.com/anthropics/skills/tree/main/skills/docx

## 何時執行

- 輸入為 `.pdf`、`.doc`、`.docx`、`.rtf`、`.html` 等**非純文字檔**時，先擷取再審查。
- 輸入本身即為 `.md`、`.txt` 或使用者貼上的文字 → 直接進審查，跳過本步驟。

## 路徑約定

> 上游 SKILL.md 的指令以 `scripts/...` 為基準；在本 skill 內請改為
> `references/pdf/scripts/...`、`references/docx/scripts/...`。

## 1. PDF（依 `references/pdf/`）

依 `references/pdf/SKILL.md`，擷取文字優先順序：

```bash
# 首選：CLI，保留版面（poppler-utils）
pdftotext -layout input.pdf runs/<id>/input.md
```

CLI 不可用時改用 Python（`references/pdf/SKILL.md` 有完整範例）：

```python
# pdfplumber：文字 + 表格（API 文件常有參數表，優先用它）
import pdfplumber
with pdfplumber.open("input.pdf") as pdf:
    text = "\n".join((p.extract_text() or "") for p in pdf.pages)
    # 需要參數表時：p.extract_tables()

# 或 pypdf（僅純文字）
from pypdf import PdfReader
text = "".join(p.extract_text() for p in PdfReader("input.pdf").pages)
```

**掃描版 PDF（無文字層）**：`pdftotext` / pdfplumber 會回傳空白。此時走 OCR
（見 `references/pdf/SKILL.md` 的 “Extract Text from Scanned PDFs”，`pytesseract` + `pdf2image`），
並在審查報告 Meta 標註「來源為 OCR，文字可能有誤差」。

## 2. Word（依 `references/docx/`）

```bash
# .docx → Markdown（含追蹤修訂，最完整）
pandoc --track-changes=all input.docx -o runs/<id>/input.md

# 舊版 .doc 需先轉 .docx
python references/docx/scripts/office/soffice.py --headless --convert-to docx input.doc
```

`pandoc` / LibreOffice 皆不可用時的 fallback（macOS 內建）：

```bash
textutil -convert txt input.docx -output runs/<id>/input.md   # 支援 doc/docx/rtf/html/txt
```

## 3. 擷取後處置

1. 將擷取結果寫入 `runs/<id>/input.md`，作為審查的正式輸入。
2. 於審查報告 Meta 記錄：原始檔名、格式、擷取工具、是否為 OCR。
3. **擷取失敗或內容明顯殘缺**（空白、亂碼、僅剩頁碼）→ 不硬審，直接回覆使用者
   說明無法擷取，並請改提供純文字 / Markdown，或確認檔案是否為掃描影像需 OCR。

## 依賴

```bash
# PDF
pip install pypdf pdfplumber            # 文字/表格擷取
pip install pytesseract pdf2image       # 掃描版 OCR（另需系統 tesseract、poppler）
# 或系統工具：poppler-utils（pdftotext / pdfimages）

# Word
# pandoc（.docx→md）、LibreOffice soffice（.doc→.docx / 轉檔）
# 皆缺時可用 macOS 內建 textutil
```
