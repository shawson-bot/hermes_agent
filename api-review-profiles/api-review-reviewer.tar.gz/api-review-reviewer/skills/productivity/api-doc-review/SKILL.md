---
name: api-doc-review
description: >
  審查 API 文件並做技術契約缺口檢核。當使用者上傳/貼上 API 文件（各種文字檔案格式，
  如 PDF、Word（doc/docx）、Markdown、純文字，或 OpenAPI/Swagger 文字）並要求審查、
  評分、找缺漏、資安掃描或補件建議時觸發。
  產出含 API 健康分數（0–100）、結論狀態（可進入開發 / 需補件 / 高風險不建議接入）、
  P0–P3 問題分級與供應商待確認問題單的 Markdown 審查報告。
---

# API 文件審查 Skill

照 `prompts/reviewer.md` 的角色與步驟執行，依 `references/` 下規範檔評分與檢核：

- `references/extract.md` — 輸入為 PDF/Word 等檔案時的文字擷取流程（封裝官方 `pdf`/`docx` skill 於 `references/pdf/`、`references/docx/`）
- `references/rubric.md` — 5 構面健康分數、門檻與結論狀態
- `references/checks.md` — 核心檢查規則、資安掃描、P0–P3 分級、供應商問題單
- `references/gold-standard.md` — 好文件特徵
- `references/report-template.md` — 完整報告結構

輸出報告到 `runs/<YYYY-MM-DD-slug>/report.md`。
