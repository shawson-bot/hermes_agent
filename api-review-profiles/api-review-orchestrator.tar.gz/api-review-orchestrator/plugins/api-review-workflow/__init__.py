"""Register the API review workflow tools."""

from __future__ import annotations

from .schemas import GET_API_REVIEW_WORKFLOW_STATUS, START_API_REVIEW_WORKFLOW
from .tools import get_api_review_workflow_status, start_api_review_workflow


def register(ctx) -> None:
    ctx.register_tool(
        name="start_api_review_workflow",
        toolset="api_review_workflow",
        schema=START_API_REVIEW_WORKFLOW,
        handler=start_api_review_workflow,
    )
    ctx.register_tool(
        name="get_api_review_workflow_status",
        toolset="api_review_workflow",
        schema=GET_API_REVIEW_WORKFLOW_STATUS,
        handler=get_api_review_workflow_status,
    )
