"""Schemas exposed by the API review workflow plugin."""

START_API_REVIEW_WORKFLOW = {
    "name": "start_api_review_workflow",
    "description": (
        "Stage uploaded or prepared API-review inputs into a unique per-run "
        "workspace, perform host-side validation, and create the four-task API "
        "documentation review Kanban board. This is the only valid preflight "
        "because sandboxed file tools cannot see backend host paths. Use this "
        "instead of inspecting host paths or manually creating or linking "
        "API-review workflow tasks."
    ),
    "parameters": {
        "type": "object",
        "properties": {
            "run_name": {
                "type": "string",
                "description": (
                    "Optional unique run name used for the board and idempotency "
                    "keys. Omit it to generate a non-repeating timestamped name "
                    "after checking the existing Kanban board directory."
                ),
            },
            "max_retries": {
                "type": "integer",
                "minimum": 1,
                "maximum": 5,
                "default": 2,
                "description": "Maximum worker retries per task.",
            },
            "uploaded_files": {
                "type": "array",
                "items": {"type": "string"},
                "default": [],
                "description": (
                    "Local backend cache paths for files uploaded in the current "
                    "Studio/chat message. Pass paths from attachment notes such "
                    "as \"saved at: /path/to/file\". The launcher copies them "
                    "into the per-run input_docs folder. Supported inputs include "
                    "Markdown, text, OpenAPI/Swagger JSON/YAML, PDF, Word, RTF, "
                    "and HTML exports."
                ),
            },
            "reuse_project_inputs": {
                "type": "boolean",
                "default": True,
                "description": (
                    "When true and no uploaded_files are provided, copy all valid "
                    "non-hidden files from the legacy shared "
                    "$HERMES_API_REVIEW_ROOT/input_docs folder. Keep true for "
                    "local CLI testing; uploaded files still stage into a unique "
                    "per-run workspace."
                ),
            },
            "dispatch": {
                "type": "boolean",
                "default": True,
                "description": "Run one dispatcher pass after creating the board.",
            },
            "subscribe_updates": {
                "type": "boolean",
                "default": True,
                "description": (
                    "Subscribe the current gateway/TUI chat session to each "
                    "workflow task so completion/block messages are emitted "
                    "after every step when the active surface supports async "
                    "Kanban notifications."
                ),
            },
            "dry_run": {
                "type": "boolean",
                "default": False,
                "description": (
                    "Validate Docker, host files, and workflow dependencies "
                    "without creating a board."
                ),
            },
            "wait_for_intake": {
                "type": "boolean",
                "default": True,
                "description": (
                    "Wait for the Intake task to finish or block so its result can "
                    "be relayed by the API Review Orchestrator."
                ),
            },
            "intake_wait_seconds": {
                "type": "integer",
                "minimum": 10,
                "maximum": 300,
                "default": 120,
                "description": "Maximum time to wait for the Intake task result.",
            },
        },
        "required": [],
    },
}


GET_API_REVIEW_WORKFLOW_STATUS = {
    "name": "get_api_review_workflow_status",
    "description": (
        "Return an orchestrator-facing progress digest for an API-review run. "
        "Use this after starting the workflow, after Kanban task notifications, "
        "or when the user asks for status. It reads Kanban state plus known "
        "worker artifacts and produces one user-facing message so the API "
        "Review Orchestrator can remain the only communicator."
    ),
    "parameters": {
        "type": "object",
        "properties": {
            "run_name": {
                "type": "string",
                "description": (
                    "Run name returned by start_api_review_workflow. Used to "
                    "derive the board and per-run project folder when board or "
                    "project_root is omitted."
                ),
            },
            "board": {
                "type": "string",
                "description": "Optional Kanban board slug, such as api-review-local-api-test.",
            },
            "project_root": {
                "type": "string",
                "description": (
                    "Optional per-run project root. Omit when run_name was used "
                    "with the canonical launcher."
                ),
            },
            "tasks": {
                "type": "object",
                "additionalProperties": {"type": "string"},
                "description": (
                    "Optional task-id map returned by start_api_review_workflow, "
                    "for example api_intake -> t_xxx."
                ),
            },
            "include_artifacts": {
                "type": "boolean",
                "default": True,
                "description": (
                    "Include short previews and existence checks for known worker "
                    "artifacts such as intake_manifest.md, api_review_report.md, "
                    "api_review_notes.md, and final_api_review_report.md."
                ),
            },
            "artifact_max_chars": {
                "type": "integer",
                "minimum": 400,
                "maximum": 12000,
                "default": 3000,
                "description": "Maximum characters to include from each artifact preview.",
            },
        },
        "required": [],
    },
}
