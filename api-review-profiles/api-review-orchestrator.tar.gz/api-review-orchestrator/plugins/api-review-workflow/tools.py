"""Host-side launcher for the fixed API documentation review workflow."""

from __future__ import annotations

import json
import os
import re
import shutil
import subprocess
import sys
import time
from datetime import datetime
from pathlib import Path
from typing import Any


def _resolve_hermes_bin() -> str:
    configured = str(os.environ.get("HERMES_BIN") or "").strip()
    if configured:
        return configured
    found = shutil.which("hermes")
    if found:
        return found
    return str(Path.home() / ".local" / "bin" / "hermes")


def _resolve_project_root() -> Path:
    configured = str(os.environ.get("HERMES_API_REVIEW_ROOT") or "").strip()
    if configured:
        return Path(configured).expanduser().resolve()
    return (Path.home() / "hermes-projects" / "api_review").resolve()


def _resolve_workflow_script() -> Path:
    configured = str(os.environ.get("HERMES_API_REVIEW_WORKFLOW_SCRIPT") or "").strip()
    if configured:
        return Path(configured).expanduser().resolve()
    return Path(__file__).resolve().parents[2] / "scripts" / "api_review_kanban.py"


HERMES_BIN = _resolve_hermes_bin()
PROJECT_ROOT = _resolve_project_root()
WORKFLOW_SCRIPT = _resolve_workflow_script()
WORKER_DOCKER_IMAGE = os.environ.get(
    "HERMES_API_REVIEW_DOCKER_IMAGE",
    "hermes-report-sandbox:rtk-0.43.0",
)
LEGACY_INPUT_DIR = PROJECT_ROOT / "input_docs"
RUNS_DIR = PROJECT_ROOT / "runs"
HERMES_HOME = Path(os.environ.get("HERMES_HOME") or Path.home() / ".hermes").expanduser()
KANBAN_BOARDS_ROOT = HERMES_HOME / "kanban" / "boards"
PROFILE = "api-review-orchestrator"
ACTIVE_RUN_MANIFEST = "active_api_review_run.json"
STEP_ORDER = (
    "api_intake",
    "compose_api_review",
    "review_api_report",
    "revise_api_review",
)
STEP_LABELS = {
    "api_intake": "Intake",
    "compose_api_review": "Composer",
    "review_api_report": "Reviewer",
    "revise_api_review": "Revision",
}
STEP_ARTIFACTS = {
    "api_intake": ("jobs/intake_manifest.md", "Intake manifest"),
    "compose_api_review": ("jobs/api_review_report.md", "Draft API review report"),
    "review_api_report": ("jobs/api_review_notes.md", "Reviewer notes"),
    "revise_api_review": ("outputs/final_api_review_report.md", "Final revised API review report"),
}
SUPPORTED_INPUT_SUFFIXES = {
    ".md", ".markdown", ".txt",
    ".json", ".yaml", ".yml",
    ".pdf", ".docx", ".doc", ".rtf",
    ".html", ".htm",
}
DENIED_SOURCE_PARTS = {
    ".ssh",
    ".aws",
    ".gnupg",
    ".config/gcloud",
    ".codex",
}
DENIED_SOURCE_NAMES = {
    ".env",
    "auth.json",
    "auth.lock",
    "state.db",
    "state.db-wal",
    "state.db-shm",
    "credentials.json",
    "application_default_credentials.json",
    "id_rsa",
    "id_ed25519",
}


def _json(payload: dict[str, Any]) -> str:
    return json.dumps(payload, ensure_ascii=False)


def _validate_run_name(value: Any) -> str:
    run_name = str(value or "").strip()
    if not run_name:
        raise ValueError("run_name is required")
    if len(run_name) > 100:
        raise ValueError("run_name must be 100 characters or fewer")
    if any(ch in run_name for ch in ("/", "\\", "\x00")):
        raise ValueError("run_name cannot contain path separators")
    return run_name


def _slugify(value: str) -> str:
    return re.sub(r"[^a-z0-9]+", "-", value.lower()).strip("-") or "api-review-run"


def _resolve_run_name(value: Any) -> str:
    if str(value or "").strip():
        return _validate_run_name(value)

    base = f"auto-{datetime.now().strftime('%Y%m%d-%H%M%S')}"
    candidate = base
    suffix = 2
    while (
        (KANBAN_BOARDS_ROOT / f"api-review-{_slugify(candidate)}").exists()
        or (_run_project_root(candidate)).exists()
    ):
        candidate = f"{base}-{suffix}"
        suffix += 1
    return candidate


def _run_project_root(run_name: str) -> Path:
    return (RUNS_DIR / _slugify(run_name)).resolve()


def _safe_filename(src: Path, used: set[str]) -> str:
    stem = re.sub(r"[^A-Za-z0-9._-]+", "-", src.stem).strip("-._") or "api-doc"
    suffix = src.suffix.lower()
    candidate = f"{stem}{suffix}"
    counter = 2
    while candidate in used:
        candidate = f"{stem}-{counter}{suffix}"
        counter += 1
    used.add(candidate)
    return candidate


def _safe_copy_source(path_value: Any) -> Path:
    raw = str(path_value or "").strip()
    if not raw:
        raise ValueError("empty attachment path")
    path = Path(raw).expanduser()
    if not path.is_absolute():
        path = path.resolve()
    else:
        path = path.resolve()
    if not path.is_file():
        raise ValueError(f"input file not found or not a regular file: {path}")
    if path.stat().st_size <= 0:
        raise ValueError(f"input file is empty: {path}")
    suffix = path.suffix.lower()
    if suffix not in SUPPORTED_INPUT_SUFFIXES:
        raise ValueError(
            f"unsupported API document type for {path.name}; upload Markdown, text, JSON/YAML, PDF, Word, RTF, or HTML"
        )

    lower_path = str(path).lower()
    lower_name = path.name.lower()
    if lower_name in DENIED_SOURCE_NAMES:
        raise ValueError(f"refusing to stage sensitive-looking file: {path.name}")
    if any(part in lower_path for part in DENIED_SOURCE_PARTS):
        try:
            path.relative_to(LEGACY_INPUT_DIR.resolve())
        except ValueError as exc:
            raise ValueError(f"refusing to stage file from sensitive folder: {path}") from exc
    if ".hermes/profiles/" in lower_path and (
        "/.env" in lower_path
        or "/auth" in lower_path
        or "/state.db" in lower_path
        or "/logs/" in lower_path
    ):
        raise ValueError(f"refusing to stage file from sensitive Hermes profile path: {path}")
    if any(token in lower_name for token in ("secret", "credential", "private_key")):
        raise ValueError(f"refusing to stage sensitive-looking file: {path.name}")
    return path


def _copy_input(src: Path, dst: Path, *, dry_run: bool) -> dict[str, Any]:
    result = {
        "source": str(src),
        "destination": str(dst),
        "bytes": src.stat().st_size,
        "copied": False,
    }
    if not dry_run:
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, dst)
        result["copied"] = True
    return result


def _stage_inputs(args: dict[str, Any], run_root: Path, *, dry_run: bool) -> dict[str, Any]:
    """Copy uploaded/chat-provided API docs into this run's input_docs folder."""
    input_dir = run_root / "input_docs"
    staged: list[dict[str, Any]] = []
    errors: list[str] = []
    ignored: list[str] = []
    sources: list[Path] = []

    uploaded = args.get("uploaded_files") or args.get("attachment_paths") or []
    if isinstance(uploaded, str):
        uploaded = [uploaded]
    if not isinstance(uploaded, list):
        raise ValueError("uploaded_files must be an array of local cached file paths")

    for raw_path in uploaded:
        try:
            src = _safe_copy_source(raw_path)
            if src not in sources:
                sources.append(src)
        except ValueError as exc:
            errors.append(str(exc))

    if args.get("reuse_project_inputs", True) and not sources and LEGACY_INPUT_DIR.is_dir():
        for path in sorted(LEGACY_INPUT_DIR.iterdir()):
            if path.name.startswith(".") or not path.is_file():
                continue
            try:
                src = _safe_copy_source(path)
                if src not in sources:
                    sources.append(src)
            except ValueError as exc:
                ignored.append(str(exc))

    used_names: set[str] = set()
    for src in sources:
        safe_name = _safe_filename(src, used_names)
        staged.append(_copy_input(src, input_dir / safe_name, dry_run=dry_run))

    return {
        "run_root": str(run_root),
        "input_dir": str(input_dir),
        "legacy_input_dir": str(LEGACY_INPUT_DIR),
        "staged": staged,
        "errors": errors,
        "ignored": ignored,
        "dry_run": dry_run,
    }


def _preflight(run_root: Path, staging: dict[str, Any]) -> dict[str, Any]:
    errors: list[str] = []
    input_errors: list[str] = []
    input_dir = run_root / "input_docs"

    if not (Path(HERMES_BIN).is_file() or shutil.which(HERMES_BIN)):
        errors.append(f"Hermes executable not found: {HERMES_BIN}")
    if not WORKFLOW_SCRIPT.is_file():
        errors.append(f"Workflow script not found: {WORKFLOW_SCRIPT}")

    sources: list[Path] = []
    if input_dir.is_dir():
        sources = sorted(
            path
            for path in input_dir.iterdir()
            if path.is_file() and not path.name.startswith(".") and path.stat().st_size > 0
        )
    elif staging.get("dry_run"):
        sources = [
            Path(item["destination"])
            for item in staging.get("staged", [])
            if isinstance(item, dict) and item.get("destination")
        ]
    if not sources:
        input_errors.append(f"No non-empty API document found in {input_dir}")

    docker_ok = False
    docker_error = ""
    docker_image_ok = False
    docker_image_error = ""
    dockerfile_path = Path(__file__).resolve().parents[2] / "scripts" / "docker" / "rtk-report" / "Dockerfile"
    docker_build_hint = (
        f"docker build -t {WORKER_DOCKER_IMAGE} "
        f"-f {dockerfile_path} {dockerfile_path.parent}"
    )
    try:
        probe = subprocess.run(
            ["docker", "version", "--format", "{{.Server.Version}}"],
            text=True,
            capture_output=True,
            timeout=10,
            check=False,
        )
        docker_ok = probe.returncode == 0
        if not docker_ok:
            docker_error = (probe.stderr or probe.stdout).strip()
    except (OSError, subprocess.TimeoutExpired) as exc:
        docker_error = str(exc)

    if not docker_ok:
        errors.append(
            "Docker daemon is unavailable"
            + (f": {docker_error}" if docker_error else "")
        )
    else:
        image_probe = subprocess.run(
            ["docker", "image", "inspect", WORKER_DOCKER_IMAGE],
            text=True,
            capture_output=True,
            timeout=10,
            check=False,
        )
        docker_image_ok = image_probe.returncode == 0
        if not docker_image_ok:
            docker_image_error = (image_probe.stderr or image_probe.stdout).strip()
            errors.append(
                f"Required worker Docker image is missing: {WORKER_DOCKER_IMAGE}. "
                f"Build it on this Hermes Studio/backend device with: {docker_build_hint}"
            )

    return {
        "ok": not errors,
        "errors": errors,
        "input_ready": not input_errors,
        "input_errors": input_errors,
        "project_base": str(PROJECT_ROOT),
        "project_root": str(run_root),
        "input_dir": str(input_dir),
        "staging": staging,
        "source_files": [str(path) for path in sources],
        "docker_ok": docker_ok,
        "docker_image": WORKER_DOCKER_IMAGE,
        "docker_image_ok": docker_image_ok,
        "docker_image_error": docker_image_error,
        "docker_build_hint": docker_build_hint,
    }


def _show_task(board: str, task_id: str) -> dict[str, Any] | None:
    result = subprocess.run(
        [
            str(HERMES_BIN),
            "-p",
            PROFILE,
            "kanban",
            "--board",
            board,
            "show",
            task_id,
            "--json",
        ],
        text=True,
        capture_output=True,
        timeout=15,
        check=False,
    )
    if result.returncode != 0:
        return None
    try:
        return json.loads(result.stdout)
    except json.JSONDecodeError:
        return None


def _task_list(board: str) -> list[dict[str, Any]]:
    result = subprocess.run(
        [
            str(HERMES_BIN),
            "-p",
            PROFILE,
            "kanban",
            "--board",
            board,
            "list",
            "--json",
        ],
        text=True,
        capture_output=True,
        timeout=15,
        check=False,
    )
    if result.returncode != 0:
        return []
    try:
        data = json.loads(result.stdout)
    except json.JSONDecodeError:
        return []
    if isinstance(data, list):
        return [item for item in data if isinstance(item, dict)]
    if isinstance(data, dict):
        tasks = data.get("tasks") or data.get("items") or []
        if isinstance(tasks, list):
            return [item for item in tasks if isinstance(item, dict)]
    return []


def _resolve_status_context(args: dict[str, Any]) -> dict[str, Any]:
    run_name = str(args.get("run_name") or "").strip()
    board = str(args.get("board") or "").strip()
    project_root_arg = str(args.get("project_root") or "").strip()

    if not run_name and board.startswith("api-review-"):
        run_name = board.removeprefix("api-review-")
    if not board and run_name:
        board = f"api-review-{_slugify(run_name)}"

    project_root = (
        Path(project_root_arg).expanduser().resolve()
        if project_root_arg
        else (_run_project_root(run_name) if run_name else None)
    )

    tasks = args.get("tasks") if isinstance(args.get("tasks"), dict) else {}
    tasks = {str(key): str(value) for key, value in tasks.items() if value}

    manifest: dict[str, Any] = {}
    if project_root:
        manifest_path = project_root / "jobs" / ACTIVE_RUN_MANIFEST
        if manifest_path.is_file():
            try:
                manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
            except (OSError, json.JSONDecodeError):
                manifest = {}
    if manifest:
        board = board or str(manifest.get("board") or "")
        run_name = run_name or str(manifest.get("run_name") or "")
        manifest_tasks = {
            "api_intake": manifest.get("intake_task_id"),
            "compose_api_review": manifest.get("composer_task_id"),
            "review_api_report": manifest.get("reviewer_task_id"),
            "revise_api_review": manifest.get("revision_task_id"),
        }
        for key, value in manifest_tasks.items():
            if value and key not in tasks:
                tasks[key] = str(value)

    if board and len(tasks) < len(STEP_ORDER):
        for item in _task_list(board):
            task_id = str(item.get("id") or item.get("task_id") or "")
            title = str(item.get("title") or "").lower()
            if not task_id:
                continue
            if "intake" in title:
                tasks.setdefault("api_intake", task_id)
            elif "critical review" in title or "reviewer" in title:
                tasks.setdefault("review_api_report", task_id)
            elif "revise" in title or "final report" in title:
                tasks.setdefault("revise_api_review", task_id)
            elif "compose" in title or "gap report" in title:
                tasks.setdefault("compose_api_review", task_id)

    return {
        "run_name": run_name,
        "board": board,
        "project_root": str(project_root) if project_root else "",
        "tasks": tasks,
        "manifest": manifest,
    }


def _artifact_preview(path: Path, max_chars: int) -> dict[str, Any]:
    artifact = {
        "host_path": str(path),
        "exists": path.is_file(),
        "bytes": 0,
        "preview": "",
        "truncated": False,
    }
    if not path.is_file():
        return artifact
    try:
        artifact["bytes"] = path.stat().st_size
        text = path.read_text(encoding="utf-8", errors="replace")
    except OSError as exc:
        artifact["error"] = str(exc)
        return artifact
    artifact["preview"] = text[:max_chars]
    artifact["truncated"] = len(text) > max_chars
    return artifact


def _status_icon(status: str) -> str:
    return {
        "done": "[done]",
        "blocked": "!",
        "running": "...",
        "ready": ">",
        "todo": "o",
        "scheduled": "~",
        "review": "?",
        "archived": "-",
    }.get(status, "-")


def _build_orchestrator_message(
    *,
    run_name: str,
    board: str,
    project_root: str,
    task_reports: list[dict[str, Any]],
    include_artifacts: bool,
) -> str:
    done_count = sum(1 for report in task_reports if report.get("status") == "done")
    blocked = [report for report in task_reports if report.get("status") == "blocked"]
    running = [report for report in task_reports if report.get("status") == "running"]

    lines = [
        f"API review run `{run_name or board}` status: {done_count}/{len(STEP_ORDER)} steps complete.",
    ]
    if project_root:
        lines.append(f"Workspace: `{project_root}`")
    if blocked:
        lines.append(
            "Blocked step: "
            + ", ".join(f"{item['label']} ({item.get('task_id', '')})" for item in blocked)
        )
    elif done_count == len(STEP_ORDER):
        lines.append("Final revised report is ready.")
    elif running:
        lines.append(
            "Currently running: "
            + ", ".join(f"{item['label']} ({item.get('task_id', '')})" for item in running)
        )

    lines.append("")
    lines.append("Step state:")
    for report in task_reports:
        status = str(report.get("status") or "unknown")
        label = report.get("label")
        task_id = report.get("task_id") or ""
        summary = (report.get("summary") or "").strip()
        line = f"{_status_icon(status)} {label}: {status}"
        if task_id:
            line += f" ({task_id})"
        lines.append(line)
        if summary:
            lines.append(f"  Summary: {summary}")
        artifact = report.get("artifact") or {}
        if include_artifacts and artifact:
            if artifact.get("exists"):
                lines.append(f"  Artifact: {artifact.get('host_path')}")
            elif status == "done":
                lines.append(f"  Artifact expected but not found: {artifact.get('host_path')}")

    if blocked:
        reason = (blocked[0].get("summary") or blocked[0].get("latest_event_error") or "").strip()
        if reason:
            lines.extend(["", f"Next action: {reason}"])
    return "\n".join(lines)


def _wait_for_intake(
    board: str,
    task_id: str,
    timeout_seconds: int,
) -> dict[str, Any]:
    deadline = time.monotonic() + timeout_seconds
    latest: dict[str, Any] | None = None
    while time.monotonic() < deadline:
        latest = _show_task(board, task_id)
        status = (latest or {}).get("task", {}).get("status")
        if status in {"done", "blocked"}:
            return {
                "status": status,
                "summary": (latest or {}).get("latest_summary"),
                "task_id": task_id,
            }
        time.sleep(2)

    return {
        "status": (latest or {}).get("task", {}).get("status", "pending"),
        "summary": (latest or {}).get("latest_summary"),
        "task_id": task_id,
        "timed_out": True,
    }


def _notification_target() -> dict[str, str] | None:
    """Return the current gateway/TUI notification target, if one exists."""
    try:
        from hermes_cli.config import cfg_get, load_config

        cfg = load_config()
        if not cfg_get(cfg, "kanban", "auto_subscribe_on_create", default=True):
            return None
    except Exception:
        # Match kanban_create's user-friendly default: if config cannot be
        # loaded, keep best-effort notification subscription enabled.
        pass

    try:
        from gateway.session_context import get_session_env
    except Exception:
        get_session_env = lambda name, default="": os.environ.get(name, default)

    platform = get_session_env("HERMES_SESSION_PLATFORM", "")
    chat_id = get_session_env("HERMES_SESSION_CHAT_ID", "")
    if not platform or not chat_id:
        session_key = (
            get_session_env("HERMES_SESSION_KEY", "")
            or os.environ.get("HERMES_SESSION_KEY", "")
        )
        if not session_key:
            return None
        platform = "tui"
        chat_id = session_key

    return {
        "platform": platform,
        "chat_id": chat_id,
        "thread_id": get_session_env("HERMES_SESSION_THREAD_ID", "") or "",
        "user_id": get_session_env("HERMES_SESSION_USER_ID", "") or "",
        "notifier_profile": os.environ.get("HERMES_PROFILE") or PROFILE,
    }


def _subscribe_workflow_updates(board: str, tasks: dict[str, str]) -> dict[str, Any]:
    """Subscribe the current chat/TUI session to all workflow task events."""
    target = _notification_target()
    task_ids = [task_id for task_id in tasks.values() if task_id]
    result: dict[str, Any] = {
        "enabled": bool(target),
        "target": target,
        "subscribed_task_ids": [],
        "skipped_task_ids": [],
        "error": "",
    }
    if not target or not task_ids:
        result["skipped_task_ids"] = task_ids
        return result

    try:
        from hermes_cli import kanban_db as _kb

        conn = _kb.connect(board=board)
        try:
            for task_id in task_ids:
                _kb.add_notify_sub(
                    conn,
                    task_id=task_id,
                    platform=target["platform"],
                    chat_id=target["chat_id"],
                    thread_id=target.get("thread_id") or None,
                    user_id=target.get("user_id") or None,
                    notifier_profile=target.get("notifier_profile") or None,
                )
                result["subscribed_task_ids"].append(task_id)
        finally:
            conn.close()
    except Exception as exc:
        result["error"] = str(exc)
        result["skipped_task_ids"] = task_ids
        result["subscribed_task_ids"] = []
    return result


def _dispatch_board(board: str) -> dict[str, Any]:
    result = subprocess.run(
        [
            str(HERMES_BIN),
            "-p",
            PROFILE,
            "kanban",
            "--board",
            board,
            "dispatch",
            "--max",
            "4",
        ],
        text=True,
        capture_output=True,
        timeout=90,
        check=False,
    )
    return {
        "requested": True,
        "ok": result.returncode == 0,
        "exit_code": result.returncode,
        "output": (result.stdout or "").strip(),
        "error": (result.stderr or "").strip(),
    }


def get_api_review_workflow_status(args: dict[str, Any], **_: Any) -> str:
    """Return a user-facing digest of the API-review workflow state."""
    try:
        context = _resolve_status_context(args)
        board = context["board"]
        project_root = context["project_root"]
        tasks = context["tasks"]
        if not board:
            return _json({
                "status": "error",
                "error": "board or run_name is required",
            })

        include_artifacts = bool(args.get("include_artifacts", True))
        max_chars = int(args.get("artifact_max_chars", 3000))
        if not 400 <= max_chars <= 12000:
            raise ValueError("artifact_max_chars must be between 400 and 12000")

        task_reports: list[dict[str, Any]] = []
        for step_id in STEP_ORDER:
            task_id = tasks.get(step_id, "")
            shown = _show_task(board, task_id) if task_id else None
            task = (shown or {}).get("task") or {}
            status = str(task.get("status") or "unknown")
            latest_summary = (shown or {}).get("latest_summary") or task.get("result") or ""
            events = (shown or {}).get("events") or []
            latest_event_error = ""
            for event in reversed(events):
                payload = event.get("payload") if isinstance(event, dict) else {}
                if isinstance(payload, dict) and payload.get("error"):
                    latest_event_error = str(payload.get("error"))
                    break

            report: dict[str, Any] = {
                "step_id": step_id,
                "label": STEP_LABELS[step_id],
                "task_id": task_id,
                "assignee": task.get("assignee"),
                "status": status,
                "summary": latest_summary,
                "latest_event_error": latest_event_error,
                "title": task.get("title"),
            }

            if include_artifacts and project_root:
                rel_path, artifact_label = STEP_ARTIFACTS[step_id]
                artifact = _artifact_preview(Path(project_root) / rel_path, max_chars)
                artifact["label"] = artifact_label
                artifact["container_path"] = f"/workspace/{rel_path}"
                report["artifact"] = artifact
            task_reports.append(report)

        message = _build_orchestrator_message(
            run_name=context["run_name"],
            board=board,
            project_root=project_root,
            task_reports=task_reports,
            include_artifacts=include_artifacts,
        )
        done_count = sum(1 for report in task_reports if report.get("status") == "done")
        blocked_count = sum(1 for report in task_reports if report.get("status") == "blocked")

        return _json({
            "status": "complete" if done_count == len(STEP_ORDER) else "blocked" if blocked_count else "running",
            "run_name": context["run_name"],
            "board": board,
            "project_root": project_root,
            "tasks": tasks,
            "task_reports": task_reports,
            "orchestrator_message": message,
        })
    except (TypeError, ValueError) as exc:
        return _json({"status": "error", "error": str(exc)})
    except Exception as exc:
        return _json({"status": "error", "error": f"Unexpected status error: {exc}"})


def start_api_review_workflow(args: dict[str, Any], **_: Any) -> str:
    """Validate inputs and invoke the canonical API-review Kanban builder."""
    try:
        run_name = _resolve_run_name(args.get("run_name"))
        max_retries = int(args.get("max_retries", 2))
        if not 1 <= max_retries <= 5:
            raise ValueError("max_retries must be between 1 and 5")

        run_root = _run_project_root(run_name)
        dry_run = bool(args.get("dry_run", False))
        staging = _stage_inputs(args, run_root, dry_run=dry_run)
        preflight = _preflight(run_root, staging)
        if staging["errors"]:
            preflight["errors"].extend(staging["errors"])
            preflight["ok"] = False

        if dry_run or not preflight["ok"]:
            return _json({
                "status": "ready" if preflight["ok"] else "blocked",
                "dry_run": dry_run,
                "run_name": run_name,
                "preflight": preflight,
                "welcome_message": (
                    f"API review run `{run_name}` is ready to start. "
                    f"Inputs will be staged under `{preflight['input_dir']}` "
                    "and the workflow will run Intake, Composer, Reviewer, then Revision."
                ),
            })

        command = [
            sys.executable,
            str(WORKFLOW_SCRIPT),
            run_name,
            "--project-root",
            str(run_root),
            "--profile",
            PROFILE,
            "--hermes",
            str(HERMES_BIN),
            "--max-retries",
            str(max_retries),
            "--worker-docker-image",
            WORKER_DOCKER_IMAGE,
        ]
        result = subprocess.run(
            command,
            text=True,
            capture_output=True,
            timeout=90,
            check=False,
        )
        if result.returncode != 0:
            return _json({
                "status": "error",
                "run_name": run_name,
                "exit_code": result.returncode,
                "error": (result.stderr or result.stdout).strip(),
            })

        try:
            workflow = json.loads(result.stdout)
        except json.JSONDecodeError:
            return _json({
                "status": "error",
                "run_name": run_name,
                "error": "Workflow launcher returned invalid JSON",
                "output": result.stdout[-4000:],
            })

        notifications = {"enabled": False}
        if args.get("subscribe_updates", True):
            notifications = _subscribe_workflow_updates(
                workflow["board"],
                workflow.get("tasks", {}),
            )

        dispatch_result = {"requested": False}
        if args.get("dispatch", True):
            dispatch_result = _dispatch_board(workflow["board"])
            if not dispatch_result["ok"]:
                return _json({
                    "status": "error",
                    "run_name": run_name,
                    "preflight": preflight,
                    "workflow": workflow,
                    "notifications": notifications,
                    "dispatch": dispatch_result,
                    "error": "Workflow board was created, but dispatch failed",
                })

        intake = {
            "status": "pending",
            "task_id": workflow.get("tasks", {}).get("api_intake"),
        }
        intake_task_id = intake["task_id"]
        if args.get("wait_for_intake", True) and intake_task_id:
            wait_seconds = int(args.get("intake_wait_seconds", 120))
            if not 10 <= wait_seconds <= 300:
                raise ValueError("intake_wait_seconds must be between 10 and 300")
            intake = _wait_for_intake(workflow["board"], intake_task_id, wait_seconds)

        status_digest = json.loads(get_api_review_workflow_status({
            "run_name": run_name,
            "board": workflow["board"],
            "project_root": workflow["project_root"],
            "tasks": workflow.get("tasks", {}),
            "include_artifacts": False,
        }))

        return _json({
            "status": "started",
            "run_name": run_name,
            "preflight": preflight,
            "workflow": workflow,
            "dispatch": dispatch_result,
            "intake": intake,
            "notifications": notifications,
            "welcome_message": (
                f"API review run `{run_name}` has started. I will keep the "
                "main orchestrator chat as the user-facing channel and relay "
                "worker progress/results from Kanban."
            ),
            "orchestrator_message": status_digest.get("orchestrator_message", ""),
            "next_action": (
                "If intake is blocked, relay its summary and designated input "
                "path to the user. Otherwise monitor the returned task IDs and "
                "relay the final revised report and Reviewer verdict when complete."
            ),
        })
    except (TypeError, ValueError) as exc:
        return _json({"status": "error", "error": str(exc)})
    except Exception as exc:
        return _json({"status": "error", "error": f"Unexpected launcher error: {exc}"})
