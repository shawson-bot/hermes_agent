# API Review Backend Runtime Cookbook

This profile bundle intentionally does not include machine-local runtime state:

- Docker images
- GBrain databases
- GBrain/GStack cloned repositories
- auth files, tokens, provider keys, logs, sessions, memories, or caches

After importing the profiles into Hermes Studio, run these commands on the
backend device that hosts Hermes Studio.

## 1. Enter the orchestrator profile

```sh
cd ~/.hermes/profiles/api-review-orchestrator
```

## 2. Build the RTK Docker sandbox image

The API-review worker agents expect this image by default:

```text
hermes-report-sandbox:rtk-0.43.0
```

Build it once:

```sh
scripts/docker/rtk-report/build.sh
```

Verify it:

```sh
docker image ls | grep hermes-report-sandbox
docker run --rm hermes-report-sandbox:rtk-0.43.0 rtk --version
```

To use another image name, set this on the backend before running the workflow:

```sh
export HERMES_API_REVIEW_DOCKER_IMAGE=your-image-name:tag
```

## 3. Install GBrain and GStack on the backend

This is optional for the API-review flow, but useful if you want those tools
available in Hermes Studio.

```sh
scripts/setup_gbrain_gstack.sh
```

Optional local backend brain initialization:

```sh
PATH="$HOME/.bun/bin:$PATH" gbrain init --pglite --no-embedding
```

Verify:

```sh
PATH="$HOME/.bun/bin:$PATH" gbrain --version
find ~/.hermes/profiles/api-review-orchestrator/skills -maxdepth 1 -name 'gstack*' | wc -l
```

## 4. Project folder behavior

Each workflow run creates an isolated run folder:

```text
~/hermes-projects/api_review/runs/<run_id>/
  input_docs/
  jobs/
  outputs/
  scratch/
  template/
```

Worker agents receive Docker mounts for only the current run folder, translated
inside Docker as `/workspace/...`.

The export does not include old `runs/` folders. That is expected; run folders
are generated at runtime.

## 5. Provider credentials

Provider credentials must be configured on the backend. They are not exported.

Check Hermes Studio provider/env settings after import, then test the workflow
from the orchestrator profile.
