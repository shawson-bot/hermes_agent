#!/usr/bin/env sh
set -eu

IMAGE="${HERMES_API_REVIEW_DOCKER_IMAGE:-hermes-report-sandbox:rtk-0.43.0}"
DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"

docker build -t "$IMAGE" -f "$DIR/Dockerfile" "$DIR"
docker run --rm "$IMAGE" sh -lc 'rtk --version && python --version && node --version'
