#!/usr/bin/env sh
set -eu

# Install GBrain + GStack for this Hermes backend and expose GStack skills to
# the API-review orchestrator profile. This script intentionally does not copy
# or export an existing ~/.gbrain database, tokens, logs, sessions, or secrets.

SCRIPT_DIR="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
PROFILE_DIR="$(CDPATH= cd -- "$SCRIPT_DIR/.." && pwd)"
HERMES_HOME="${HERMES_HOME:-$HOME/.hermes}"
GLOBAL_SKILLS_DIR="$HERMES_HOME/skills"
PROFILE_SKILLS_DIR="$PROFILE_DIR/skills"
GSTACK_DIR="${GSTACK_DIR:-$HERMES_HOME/vendor/gstack}"

mkdir -p "$GLOBAL_SKILLS_DIR" "$PROFILE_SKILLS_DIR" "$(dirname "$GSTACK_DIR")"

if ! command -v bun >/dev/null 2>&1; then
  if [ ! -x "$HOME/.bun/bin/bun" ]; then
    curl -fsSL https://bun.sh/install | bash
  fi
  export PATH="$HOME/.bun/bin:$PATH"
fi

if ! command -v bun >/dev/null 2>&1; then
  echo "bun is still unavailable after install; add ~/.bun/bin to PATH and rerun." >&2
  exit 1
fi

bun install -g github:garrytan/gbrain

if [ -d "$GSTACK_DIR/.git" ]; then
  git -C "$GSTACK_DIR" pull --ff-only
else
  rm -rf "$GSTACK_DIR"
  git clone --single-branch --depth 1 https://github.com/garrytan/gstack.git "$GSTACK_DIR"
fi

(
  cd "$GSTACK_DIR"
  bun install
  bun run build
  bun run gen:skill-docs --host hermes
)

for skill_dir in "$GSTACK_DIR"/.hermes/skills/gstack*; do
  [ -d "$skill_dir" ] || continue
  name="$(basename "$skill_dir")"
  ln -snf "$skill_dir" "$GLOBAL_SKILLS_DIR/$name"
  ln -snf "$skill_dir" "$PROFILE_SKILLS_DIR/$name"
done

(
  cd "$GSTACK_DIR/.hermes/skills/gstack"
  ln -snf "$GSTACK_DIR/bin" bin
  ln -snf "$GSTACK_DIR/browse" browse
  ln -snf "$GSTACK_DIR/design" design
  ln -snf "$GSTACK_DIR/make-pdf" make-pdf
  ln -snf "$GSTACK_DIR/ETHOS.md" ETHOS.md
)

echo "Installed gbrain: $(PATH="$HOME/.bun/bin:$PATH" gbrain --version 2>/dev/null || true)"
echo "Linked GStack skills into:"
echo "  $GLOBAL_SKILLS_DIR"
echo "  $PROFILE_SKILLS_DIR"
echo
echo "Optional local brain init, if this backend should keep its own memory:"
echo "  PATH=\"\$HOME/.bun/bin:\$PATH\" gbrain init --pglite --no-embedding"
