# GBrain and GStack Backend Setup

This profile contains `scripts/setup_gbrain_gstack.sh` so an imported Hermes
Studio backend can recreate the same GBrain/GStack environment without exporting
private local state.

Run this on the Hermes Studio backend after importing the profile:

```sh
cd ~/.hermes/profiles/api-review-orchestrator
scripts/setup_gbrain_gstack.sh
```

The script installs or updates:

- Bun, if missing
- `gbrain` CLI via Bun
- `gstack` under `$HERMES_HOME/vendor/gstack`
- generated Hermes-format `gstack-*` skills
- symlinks in both `$HERMES_HOME/skills` and this profile's `skills/`

It does not export or copy:

- `~/.gbrain/brain.pglite`
- API keys
- tokens
- logs
- sessions
- memories

Initialize a fresh backend-local brain only when desired:

```sh
PATH="$HOME/.bun/bin:$PATH" gbrain init --pglite --no-embedding
```
